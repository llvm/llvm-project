#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x55bfb0fd, "platform_device_register_full" },
	{ 0x85acaba2, "cancel_delayed_work_sync" },
	{ 0x82fd7238, "__ubsan_handle_shift_out_of_bounds" },
	{ 0xce08e170, "release_resource" },
	{ 0x12ad300e, "iounmap" },
	{ 0x2044b429, "iomem_resource" },
	{ 0x24db4285, "__release_region" },
	{ 0xbeb1d261, "destroy_workqueue" },
	{ 0xc68d7731, "device_destroy" },
	{ 0xfbc10eaa, "class_destroy" },
	{ 0xd2a864c6, "cdev_del" },
	{ 0x0bc5fb0d, "unregister_chrdev_region" },
	{ 0xaef1f20d, "system_wq" },
	{ 0x8ce83585, "queue_delayed_work_on" },
	{ 0xe54e0a6b, "__fortify_panic" },
	{ 0x092a35a2, "_copy_from_user" },
	{ 0x058c185a, "jiffies" },
	{ 0xe199f25f, "jiffies_to_msecs" },
	{ 0xbd03ed67, "random_kmalloc_seed" },
	{ 0x4ac4312d, "kmalloc_caches" },
	{ 0x8d1d7639, "__kmalloc_cache_noprof" },
	{ 0x12ca6142, "ktime_get_with_offset" },
	{ 0x97acb853, "ktime_get" },
	{ 0xa53f4e29, "memcpy" },
	{ 0x75738bed, "__warn_printk" },
	{ 0x67628f51, "msleep" },
	{ 0x55e5dc35, "acpi_get_handle" },
	{ 0x651bbffe, "acpi_evaluate_object" },
	{ 0x97d7321b, "acpi_format_exception" },
	{ 0xa96d32ba, "__udelay" },
	{ 0x96c07e76, "const_pcpu_hot" },
	{ 0x7851be11, "__SCT__cond_resched" },
	{ 0xe17d12a1, "thermal_zone_get_temp" },
	{ 0xd710adbf, "__kmalloc_large_noprof" },
	{ 0xc1e6c71e, "__mutex_init" },
	{ 0xdf4bee3d, "alloc_workqueue" },
	{ 0x71798f7e, "delayed_work_timer_fn" },
	{ 0x02f9bbf0, "init_timer_key" },
	{ 0x9f222e1e, "alloc_chrdev_region" },
	{ 0xeb9d7920, "cdev_init" },
	{ 0xf212d1ce, "cdev_add" },
	{ 0x3d568d84, "class_create" },
	{ 0x0cf2b0e8, "device_create" },
	{ 0x1d177ede, "default_llseek" },
	{ 0x73bebd3f, "param_ops_bool" },
	{ 0x73bebd3f, "param_ops_uint" },
	{ 0x73bebd3f, "param_ops_charp" },
	{ 0xd272d446, "__fentry__" },
	{ 0xe8213e80, "_printk" },
	{ 0x97dd6ca9, "ioremap" },
	{ 0xd272d446, "__x86_return_thunk" },
	{ 0x90a48d82, "__ubsan_handle_out_of_bounds" },
	{ 0x23f25c0a, "__dynamic_pr_debug" },
	{ 0x40a621c5, "snprintf" },
	{ 0xa61fd7aa, "__check_object_size" },
	{ 0x092a35a2, "_copy_to_user" },
	{ 0xd272d446, "__stack_chk_fail" },
	{ 0xe4de56b4, "__ubsan_handle_load_invalid_value" },
	{ 0xf46d5bf3, "mutex_lock" },
	{ 0xcb8b6ec6, "kfree" },
	{ 0xf46d5bf3, "mutex_unlock" },
	{ 0xaa711385, "platform_driver_unregister" },
	{ 0xcbae5412, "__const_udelay" },
	{ 0x0e6689c1, "__platform_driver_register" },
	{ 0x70eca2ca, "module_layout" },
};

static const u32 ____version_ext_crcs[]
__used __section("__version_ext_crcs") = {
	0x55bfb0fd,
	0x85acaba2,
	0x82fd7238,
	0xce08e170,
	0x12ad300e,
	0x2044b429,
	0x24db4285,
	0xbeb1d261,
	0xc68d7731,
	0xfbc10eaa,
	0xd2a864c6,
	0x0bc5fb0d,
	0xaef1f20d,
	0x8ce83585,
	0xe54e0a6b,
	0x092a35a2,
	0x058c185a,
	0xe199f25f,
	0xbd03ed67,
	0x4ac4312d,
	0x8d1d7639,
	0x12ca6142,
	0x97acb853,
	0xa53f4e29,
	0x75738bed,
	0x67628f51,
	0x55e5dc35,
	0x651bbffe,
	0x97d7321b,
	0xa96d32ba,
	0x96c07e76,
	0x7851be11,
	0xe17d12a1,
	0xd710adbf,
	0xc1e6c71e,
	0xdf4bee3d,
	0x71798f7e,
	0x02f9bbf0,
	0x9f222e1e,
	0xeb9d7920,
	0xf212d1ce,
	0x3d568d84,
	0x0cf2b0e8,
	0x1d177ede,
	0x73bebd3f,
	0x73bebd3f,
	0x73bebd3f,
	0xd272d446,
	0xe8213e80,
	0x97dd6ca9,
	0xd272d446,
	0x90a48d82,
	0x23f25c0a,
	0x40a621c5,
	0xa61fd7aa,
	0x092a35a2,
	0xd272d446,
	0xe4de56b4,
	0xf46d5bf3,
	0xcb8b6ec6,
	0xf46d5bf3,
	0xaa711385,
	0xcbae5412,
	0x0e6689c1,
	0x70eca2ca,
};
static const char ____version_ext_names[]
__used __section("__version_ext_names") =
	"platform_device_register_full\0"
	"cancel_delayed_work_sync\0"
	"__ubsan_handle_shift_out_of_bounds\0"
	"release_resource\0"
	"iounmap\0"
	"iomem_resource\0"
	"__release_region\0"
	"destroy_workqueue\0"
	"device_destroy\0"
	"class_destroy\0"
	"cdev_del\0"
	"unregister_chrdev_region\0"
	"system_wq\0"
	"queue_delayed_work_on\0"
	"__fortify_panic\0"
	"_copy_from_user\0"
	"jiffies\0"
	"jiffies_to_msecs\0"
	"random_kmalloc_seed\0"
	"kmalloc_caches\0"
	"__kmalloc_cache_noprof\0"
	"ktime_get_with_offset\0"
	"ktime_get\0"
	"memcpy\0"
	"__warn_printk\0"
	"msleep\0"
	"acpi_get_handle\0"
	"acpi_evaluate_object\0"
	"acpi_format_exception\0"
	"__udelay\0"
	"const_pcpu_hot\0"
	"__SCT__cond_resched\0"
	"thermal_zone_get_temp\0"
	"__kmalloc_large_noprof\0"
	"__mutex_init\0"
	"alloc_workqueue\0"
	"delayed_work_timer_fn\0"
	"init_timer_key\0"
	"alloc_chrdev_region\0"
	"cdev_init\0"
	"cdev_add\0"
	"class_create\0"
	"device_create\0"
	"default_llseek\0"
	"param_ops_bool\0"
	"param_ops_uint\0"
	"param_ops_charp\0"
	"__fentry__\0"
	"_printk\0"
	"ioremap\0"
	"__x86_return_thunk\0"
	"__ubsan_handle_out_of_bounds\0"
	"__dynamic_pr_debug\0"
	"snprintf\0"
	"__check_object_size\0"
	"_copy_to_user\0"
	"__stack_chk_fail\0"
	"__ubsan_handle_load_invalid_value\0"
	"mutex_lock\0"
	"kfree\0"
	"mutex_unlock\0"
	"platform_driver_unregister\0"
	"__const_udelay\0"
	"__platform_driver_register\0"
	"module_layout\0"
;

MODULE_INFO(depends, "");


MODULE_INFO(srcversion, "DC5176C856373B8F270FD34");
