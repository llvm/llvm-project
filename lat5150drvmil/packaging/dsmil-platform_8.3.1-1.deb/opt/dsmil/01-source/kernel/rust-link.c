// Auto-generated Rust linkage file
void rust_force_link(void) {}
