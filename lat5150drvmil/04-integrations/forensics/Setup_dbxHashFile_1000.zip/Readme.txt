=================================
dbxHashFile - System Requirements
=================================

To run this application, the following component must be installed on the system:

    Microsoft .NET Desktop Runtime version 8.x (x64)

The .NET runtime is a fundamental prerequisite for the correct operation of the application, as dbxHashFile is developed using the .NET 8 platform.

------------------------------------------
Automatic Runtime Installation
------------------------------------------

If the .NET Desktop Runtime 8.x is not already installed on the system, it will be automatically detected at the first launch of the program. A guided installation procedure will then start.

No manual intervention is required: the user can simply follow the automatic process, which will install the necessary component in just a few steps.

------------------------------------------
Manual Installation (Alternative)
------------------------------------------

Alternatively, you can install the .NET Desktop Runtime 8.x manually by downloading it directly from the official Microsoft website at the following address:

    https://dotnet.microsoft.com/en-en/download/dotnet/8.0

Make sure to select and install the **“.NET Desktop Runtime” for Windows (x64)** version.

Once the runtime installation is complete, the application can be launched normally.

------------------------------------------
Contact and Support
------------------------------------------

Official website: https://www.dbxforensics.com  
Developer contact: davide@dbxforensics.com


