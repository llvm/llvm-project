#!/usr/bin/env bash
# Intel Meteor Lake Optimization Suite - Master Installer
# Version: 7.0 - Complete NPU/GNA/GPU Support
# KYBERLOCK Research Division

set -euo pipefail
IFS=$'\n\t'

# Colors for output
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m' # No Color

# Configuration
readonly SUITE_VERSION="7.0"
readonly INSTALL_DIR="${1:-$HOME/intel_opt_suite}"
readonly LOG_FILE="/tmp/intel_opt_install_$(date +%Y%m%d_%H%M%S).log"

# Logging functions
log() { echo -e "${GREEN}[INFO]${NC} $*" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[ERROR]${NC} $*" | tee -a "$LOG_FILE"; }
die() { error "$*"; exit 1; }

# Print banner
print_banner() {
    cat << 'EOF'
╔══════════════════════════════════════════════════════════════════╗
║     Intel Meteor Lake Optimization Suite v7.0                   ║
║     Enhanced NPU/GNA/GPU Detection & Optimization               ║
║     KYBERLOCK Research Division                                 ║
╚══════════════════════════════════════════════════════════════════╝
EOF
}

# Check system requirements
check_requirements() {
    log "Checking system requirements..."
    
    # Check CPU
    if ! grep -q "GenuineIntel" /proc/cpuinfo; then
        die "This suite requires an Intel CPU"
    fi
    
    # Check architecture
    local arch=$(uname -m)
    if [[ "$arch" != "x86_64" ]]; then
        die "This suite requires x86_64 architecture"
    fi
    
    # Check kernel version (5.15+ recommended for NPU support)
    local kernel_version=$(uname -r | cut -d. -f1,2)
    if (( $(echo "$kernel_version < 5.15" | bc -l) )); then
        warn "Kernel $kernel_version detected. 5.15+ recommended for full NPU support"
    fi
    
    # Check for required tools
    local required_tools=("gcc" "make" "python3")
    for tool in "${required_tools[@]}"; do
        if ! command -v "$tool" &> /dev/null; then
            error "$tool not found"
            error "Install with: sudo apt-get install build-essential python3"
            exit 1
        fi
    done
    
    log "System requirements met"
}

# Detect CPU architecture
detect_cpu_arch() {
    log "Detecting CPU architecture..."
    
    local model=$(grep -m1 "model" /proc/cpuinfo | grep -oE "[0-9]+" | tail -1)
    local model_hex=$(printf "0x%X" "$model")
    local arch="unknown"
    
    case "$model_hex" in
        0xAA|0xAC)
            arch="meteorlake"
            log "Detected: Intel Meteor Lake (Core Ultra 1st Gen)"
            ;;
        0xBD|0xBE)
            arch="lunarlake"
            log "Detected: Intel Lunar Lake (Core Ultra 2nd Gen)"
            ;;
        0xC5|0xC6)
            arch="arrowlake"
            log "Detected: Intel Arrow Lake (Core Ultra Desktop)"
            ;;
        0xB7|0xBA)
            arch="raptorlake"
            log "Detected: Intel Raptor Lake (13th/14th Gen Core)"
            ;;
        0x97|0x9A|0xBF)
            arch="alderlake"
            log "Detected: Intel Alder Lake (12th Gen Core)"
            ;;
        *)
            arch="generic"
            warn "Unknown Intel CPU model: $model_hex"
            log "Using generic Intel optimizations"
            ;;
    esac
    
    export INTEL_ARCH="$arch"
}

# Detect accelerators
detect_accelerators() {
    log "Detecting Intel accelerators..."
    
    # NPU/VPU Detection
    if [[ -c /dev/accel/accel0 ]] || [[ -c /dev/vpu0 ]]; then
        log "✓ NPU/VPU detected"
        export HAS_NPU=1
        
        # Try to get NPU generation
        if [[ -f /sys/class/accel/accel0/device/device ]]; then
            local device_id=$(cat /sys/class/accel/accel0/device/device 2>/dev/null)
            case "$device_id" in
                0x7d1d)
                    log "  NPU: VPU 3720 (Meteor Lake)"
                    export NPU_GEN="3720"
                    ;;
                0x643e)
                    log "  NPU: NPU 4000 (Lunar Lake)"
                    export NPU_GEN="4000"
                    ;;
            esac
        fi
    else
        warn "✗ NPU/VPU not detected"
        export HAS_NPU=0
    fi
    
    # GPU Detection
    if [[ -d /sys/class/drm ]]; then
        for card in /sys/class/drm/card*; do
            if [[ -f "$card/device/vendor" ]]; then
                local vendor=$(cat "$card/device/vendor" 2>/dev/null)
                if [[ "$vendor" == "0x8086" ]]; then
                    log "✓ Intel GPU detected"
                    export HAS_GPU=1
                    
                    # Identify GPU generation
                    if [[ -f "$card/device/device" ]]; then
                        local device=$(cat "$card/device/device" 2>/dev/null)
                        case "${device:0:4}" in
                            0x7d)
                                log "  GPU: Intel Arc Graphics (Meteor Lake Xe-LPG)"
                                export GPU_ARCH="xe-lpg"
                                ;;
                            0x64)
                                log "  GPU: Intel Arc Graphics (Lunar Lake Xe2-LPG)"
                                export GPU_ARCH="xe2-lpg"
                                ;;
                            0x46)
                                log "  GPU: Intel Iris Xe Graphics"
                                export GPU_ARCH="xe"
                                ;;
                        esac
                    fi
                    break
                fi
            fi
        done
    fi
    [[ "${HAS_GPU:-0}" != "1" ]] && warn "✗ Intel GPU not detected"
    
    # GNA Detection
    if [[ -c /dev/gna0 ]]; then
        log "✓ GNA (Gaussian Neural Accelerator) detected"
        export HAS_GNA=1
    else
        warn "✗ GNA not detected"
        export HAS_GNA=0
    fi
    
    # Other accelerators
    [[ -c /dev/sgx_enclave ]] && log "✓ SGX detected" || warn "✗ SGX not detected"
    [[ -c /dev/qat_adf_ctl ]] && log "✓ QAT detected" || warn "✗ QAT not detected"
    [[ -c /dev/dsa0 ]] && log "✓ DSA detected" || warn "✗ DSA not detected"
    [[ -c /dev/iax0 ]] && log "✓ IAA detected" || warn "✗ IAA not detected"
}

# Create installation directory
setup_install_dir() {
    log "Setting up installation directory: $INSTALL_DIR"
    
    mkdir -p "$INSTALL_DIR"/{bin,lib,include,share/doc}
    cd "$INSTALL_DIR"
}

# Install optimization scripts
install_scripts() {
    log "Installing optimization scripts..."
    
    # Create the deployment script
    cat > "$INSTALL_DIR/bin/intel_deploy.sh" << 'SCRIPT_EOF'
#!/usr/bin/env bash
# Auto-generated Intel optimization deployment script
source "$(dirname "$0")/../lib/intel_flags.sh"
exec "$@"
SCRIPT_EOF
    chmod +x "$INSTALL_DIR/bin/intel_deploy.sh"
    
    # Create the Python analyzer
    cat > "$INSTALL_DIR/bin/intel_analyze.py" << 'SCRIPT_EOF'
#!/usr/bin/env python3
import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'lib'))
from intel_system_analyzer import IntelSystemAnalyzer
analyzer = IntelSystemAnalyzer()
analyzer.analyze()
SCRIPT_EOF
    chmod +x "$INSTALL_DIR/bin/intel_analyze.py"
    
    log "Scripts installed to $INSTALL_DIR/bin/"
}

# Generate optimal compiler flags
generate_flags() {
    log "Generating optimal compiler flags..."
    
    local flags_file="$INSTALL_DIR/lib/intel_flags.sh"
    
    cat > "$flags_file" << 'FLAGS_EOF'
#!/usr/bin/env bash
# Intel Meteor Lake Optimal Compiler Flags
# Auto-generated by Intel Optimization Suite v7.0

# Base optimization
export CFLAGS_BASE="-O3 -pipe -fomit-frame-pointer -funroll-loops -fstrict-aliasing -fno-plt"
export CFLAGS_BASE="$CFLAGS_BASE -fdata-sections -ffunction-sections -flto=auto"
export LDFLAGS_BASE="-Wl,--as-needed -Wl,--gc-sections -Wl,-O1 -Wl,--hash-style=gnu -flto=auto"

FLAGS_EOF
    
    # Add architecture-specific flags
    case "$INTEL_ARCH" in
        meteorlake)
            echo 'export MARCH="-march=meteorlake"' >> "$flags_file"
            echo 'export MTUNE="-mtune=meteorlake"' >> "$flags_file"
            ;;
        lunarlake)
            echo 'export MARCH="-march=lunarlake"' >> "$flags_file"
            echo 'export MTUNE="-mtune=lunarlake"' >> "$flags_file"
            ;;
        raptorlake)
            echo 'export MARCH="-march=raptorlake"' >> "$flags_file"
            echo 'export MTUNE="-mtune=raptorlake"' >> "$flags_file"
            ;;
        alderlake)
            echo 'export MARCH="-march=alderlake"' >> "$flags_file"
            echo 'export MTUNE="-mtune=alderlake"' >> "$flags_file"
            ;;
        *)
            echo 'export MARCH="-march=native"' >> "$flags_file"
            echo 'export MTUNE="-mtune=native"' >> "$flags_file"
            ;;
    esac
    
    # Add detected features
    cat >> "$flags_file" << 'FLAGS_EOF'

# Feature detection
FEATURES=""
grep -q "avx2" /proc/cpuinfo && FEATURES="$FEATURES -mavx2"
grep -q "fma" /proc/cpuinfo && FEATURES="$FEATURES -mfma"
grep -q "avx_vnni" /proc/cpuinfo && FEATURES="$FEATURES -mavxvnni"
grep -q "avx_vnni_int8" /proc/cpuinfo && FEATURES="$FEATURES -mavxvnniint8"
grep -q "avx_vnni_int16" /proc/cpuinfo && FEATURES="$FEATURES -mavxvnniint16"
grep -q "aes" /proc/cpuinfo && FEATURES="$FEATURES -maes"
grep -q "vaes" /proc/cpuinfo && FEATURES="$FEATURES -mvaes"
grep -q "pclmulqdq" /proc/cpuinfo && FEATURES="$FEATURES -mpclmul"
grep -q "vpclmulqdq" /proc/cpuinfo && FEATURES="$FEATURES -mvpclmulqdq"
grep -q "sha_ni" /proc/cpuinfo && FEATURES="$FEATURES -msha"
grep -q "gfni" /proc/cpuinfo && FEATURES="$FEATURES -mgfni"

# AMX detection
grep -q "amx_tile" /proc/cpuinfo && FEATURES="$FEATURES -mamx-tile"
grep -q "amx_int8" /proc/cpuinfo && FEATURES="$FEATURES -mamx-int8"
grep -q "amx_bf16" /proc/cpuinfo && FEATURES="$FEATURES -mamx-bf16"

# Combined optimal flags
export CFLAGS_OPTIMAL="$CFLAGS_BASE $MARCH $MTUNE $FEATURES"
export CXXFLAGS_OPTIMAL="$CFLAGS_OPTIMAL"
export LDFLAGS_OPTIMAL="$LDFLAGS_BASE"

# P-core only flags (AVX-512 if available)
if grep -q "avx512f" /proc/cpuinfo; then
    export CFLAGS_PCORE="$CFLAGS_OPTIMAL -mavx512f -mavx512bw -mavx512vl -mavx512dq"
    grep -q "avx512_vnni" /proc/cpuinfo && export CFLAGS_PCORE="$CFLAGS_PCORE -mavx512vnni"
fi

# Security hardened flags
export CFLAGS_SECURE="$CFLAGS_OPTIMAL -D_FORTIFY_SOURCE=3 -fstack-protector-strong"
export CFLAGS_SECURE="$CFLAGS_SECURE -fstack-clash-protection -fcf-protection=full -fpie"
export LDFLAGS_SECURE="$LDFLAGS_OPTIMAL -Wl,-z,relro -Wl,-z,now -pie"

FLAGS_EOF
    
    # Add OpenVINO configuration if accelerators present
    if [[ "${HAS_NPU:-0}" == "1" ]] || [[ "${HAS_GPU:-0}" == "1" ]]; then
        cat >> "$flags_file" << 'FLAGS_EOF'

# OpenVINO Configuration
export OPENVINO_DEVICE_PRIORITY=""
FLAGS_EOF
        
        [[ "${HAS_NPU:-0}" == "1" ]] && echo 'export OPENVINO_DEVICE_PRIORITY="${OPENVINO_DEVICE_PRIORITY:+$OPENVINO_DEVICE_PRIORITY,}NPU"' >> "$flags_file"
        [[ "${HAS_GPU:-0}" == "1" ]] && echo 'export OPENVINO_DEVICE_PRIORITY="${OPENVINO_DEVICE_PRIORITY:+$OPENVINO_DEVICE_PRIORITY,}GPU"' >> "$flags_file"
        echo 'export OPENVINO_DEVICE_PRIORITY="${OPENVINO_DEVICE_PRIORITY:+$OPENVINO_DEVICE_PRIORITY,}CPU"' >> "$flags_file"
        
        [[ "${HAS_NPU:-0}" == "1" ]] && cat >> "$flags_file" << FLAGS_EOF

# NPU Configuration
export OV_NPU_COMPILER_TYPE=DRIVER
export OV_NPU_PLATFORM=${NPU_GEN:-3720}
export OV_NPU_PROFILING=OFF
export OV_NPU_ENABLE_ELTWISE_UNROLL=YES
export OV_NPU_ENABLE_CONCAT_OPTIMIZATION=YES
FLAGS_EOF
        
        [[ "${HAS_GPU:-0}" == "1" ]] && cat >> "$flags_file" << FLAGS_EOF

# GPU Configuration  
export OV_GPU_CACHE_DIR=\$HOME/.cache/openvino/gpu
export OV_GPU_ENABLE_SDPA_OPTIMIZATION=YES
export OV_GPU_MAX_NUM_THREADS=2
FLAGS_EOF
    fi
    
    chmod +x "$flags_file"
    log "Compiler flags saved to $flags_file"
}

# Create activation script
create_activation_script() {
    log "Creating activation script..."
    
    cat > "$INSTALL_DIR/activate.sh" << ACTIVATE_EOF
#!/usr/bin/env bash
# Intel Optimization Suite Environment Activation

export INTEL_OPT_SUITE="$INSTALL_DIR"
export PATH="\$INTEL_OPT_SUITE/bin:\$PATH"
source "\$INTEL_OPT_SUITE/lib/intel_flags.sh"

echo "Intel Optimization Suite v$SUITE_VERSION activated"
echo "Architecture: $INTEL_ARCH"
[[ "${HAS_NPU:-0}" == "1" ]] && echo "NPU: Enabled (Gen ${NPU_GEN:-unknown})"
[[ "${HAS_GPU:-0}" == "1" ]] && echo "GPU: Enabled (${GPU_ARCH:-unknown})"
[[ "${HAS_GNA:-0}" == "1" ]] && echo "GNA: Enabled"
echo ""
echo "Optimal CFLAGS: \$CFLAGS_OPTIMAL"
[[ -n "\${CFLAGS_PCORE:-}" ]] && echo "P-Core CFLAGS: \$CFLAGS_PCORE"
echo ""
echo "Run 'intel_analyze.py' for detailed system analysis"
ACTIVATE_EOF
    
    chmod +x "$INSTALL_DIR/activate.sh"
    log "Activation script created: $INSTALL_DIR/activate.sh"
}

# Install documentation
install_documentation() {
    log "Installing documentation..."
    
    # Copy documentation files if they exist
    for doc in README.md METEOR_LAKE_README.md; do
        [[ -f "$doc" ]] && cp "$doc" "$INSTALL_DIR/share/doc/"
    done
    
    # Create quick reference
    cat > "$INSTALL_DIR/share/doc/QUICK_REFERENCE.txt" << 'DOC_EOF'
Intel Optimization Suite v7.0 - Quick Reference

ACTIVATION:
  source ~/intel_opt_suite/activate.sh

COMPILER FLAGS:
  $CFLAGS_OPTIMAL    - Best general optimization
  $CFLAGS_PCORE      - P-core only with AVX-512
  $CFLAGS_SECURE     - Security hardened

TOOLS:
  intel_analyze.py   - Full system analysis
  intel_deploy.sh    - Deploy with optimal flags

NPU USAGE:
  export OPENVINO_DEVICE_PRIORITY="NPU,CPU"
  
GPU USAGE:
  export OPENVINO_DEVICE_PRIORITY="GPU,CPU"

BUILD EXAMPLES:
  gcc $CFLAGS_OPTIMAL -o app app.c $LDFLAGS_OPTIMAL
  g++ $CXXFLAGS_OPTIMAL -o app app.cpp $LDFLAGS_OPTIMAL

P-CORE ONLY BUILD:
  taskset -c 0-7 gcc $CFLAGS_PCORE -o app app.c

For full documentation, see share/doc/
DOC_EOF
    
    log "Documentation installed to $INSTALL_DIR/share/doc/"
}

# Test installation
test_installation() {
    log "Testing installation..."
    
    # Source the environment
    source "$INSTALL_DIR/lib/intel_flags.sh"
    
    # Test compiler flags
    if [[ -n "$CFLAGS_OPTIMAL" ]]; then
        log "✓ Compiler flags generated successfully"
    else
        error "✗ Failed to generate compiler flags"
    fi
    
    # Test simple compilation if gcc is available
    if command -v gcc &> /dev/null; then
        echo 'int main(){return 0;}' > /tmp/test.c
        if gcc $CFLAGS_OPTIMAL -o /tmp/test /tmp/test.c 2>/dev/null; then
            log "✓ Test compilation successful"
            rm -f /tmp/test /tmp/test.c
        else
            warn "✗ Test compilation failed (some flags may not be supported)"
        fi
    fi
    
    log "Installation test complete"
}

# Main installation process
main() {
    print_banner
    
    log "Starting Intel Optimization Suite installation..."
    log "Install directory: $INSTALL_DIR"
    log "Log file: $LOG_FILE"
    echo
    
    # Run installation steps
    check_requirements
    detect_cpu_arch
    detect_accelerators
    setup_install_dir
    install_scripts
    generate_flags
    create_activation_script
    install_documentation
    test_installation
    
    # Print summary
    echo
    log "════════════════════════════════════════════════════════════════"
    log "Installation Complete!"
    log "════════════════════════════════════════════════════════════════"
    echo
    echo -e "${GREEN}To activate the Intel Optimization Suite:${NC}"
    echo -e "${BLUE}  source $INSTALL_DIR/activate.sh${NC}"
    echo
    echo -e "${GREEN}To analyze your system:${NC}"
    echo -e "${BLUE}  $INSTALL_DIR/bin/intel_analyze.py${NC}"
    echo
    echo -e "${GREEN}Quick reference:${NC}"
    echo -e "${BLUE}  cat $INSTALL_DIR/share/doc/QUICK_REFERENCE.txt${NC}"
    echo
    
    # Add to shell profile if requested
    read -p "Add to ~/.bashrc for automatic activation? (y/N) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "" >> ~/.bashrc
        echo "# Intel Optimization Suite" >> ~/.bashrc
        echo "source $INSTALL_DIR/activate.sh" >> ~/.bashrc
        log "Added to ~/.bashrc"
    fi
    
    log "Installation log saved to: $LOG_FILE"
}

# Run main installation
main "$@"
