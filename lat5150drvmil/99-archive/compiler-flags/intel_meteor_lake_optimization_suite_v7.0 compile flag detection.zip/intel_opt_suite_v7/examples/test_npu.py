#!/usr/bin/env python3
"""Test NPU availability on Intel Meteor Lake"""

import os
import sys

def check_npu():
    print("Intel NPU Detection Test")
    print("=" * 40)
    
    npu_devices = ['/dev/accel/accel0', '/dev/vpu0', '/dev/npu0']
    found = False
    
    for device in npu_devices:
        if os.path.exists(device):
            print(f"✓ NPU device found: {device}")
            found = True
            
            # Try to get device info
            try:
                device_path = '/sys/class/accel/accel0/device/device'
                if os.path.exists(device_path):
                    with open(device_path, 'r') as f:
                        device_id = f.read().strip()
                        if device_id == '0x7d1d':
                            print("  Type: VPU 3720 (Meteor Lake)")
                        elif device_id == '0x643e':
                            print("  Type: NPU 4000 (Lunar Lake)")
            except:
                pass
            break
    
    if not found:
        print("✗ No NPU devices found")
        print("\nTo enable NPU:")
        print("1. Check BIOS settings")
        print("2. Install NPU driver:")
        print("   sudo apt install intel-level-zero intel-level-zero-gpu")
    
    # Check OpenVINO
    try:
        import openvino as ov
        core = ov.Core()
        devices = core.available_devices
        print(f"\nOpenVINO devices: {devices}")
    except ImportError:
        print("\nOpenVINO not installed")

if __name__ == '__main__':
    check_npu()
