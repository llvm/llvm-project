#include <immintrin.h>
#include <stdio.h>
#include <time.h>

int main() {
    printf("Intel AVX-VNNI Test for Meteor Lake\n");
    printf("====================================\n");
    
    __m256i a = _mm256_set1_epi8(1);
    __m256i b = _mm256_set1_epi8(2);
    __m256i c = _mm256_setzero_si256();
    
    clock_t start = clock();
    for(long i = 0; i < 1000000000L; i++) {
        c = _mm256_dpbusd_epi32(c, a, b);
    }
    clock_t end = clock();
    
    double elapsed = (double)(end - start) / CLOCKS_PER_SEC;
    printf("Executed 1 billion VNNI operations\n");
    printf("Time: %.2f seconds\n", elapsed);
    printf("Performance: %.2f GOPS\n", 1.0 / elapsed);
    
    return 0;
}
