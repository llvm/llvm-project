# Intel Meteor Lake Optimization Suite v7.0 - Complete Package

## 🚀 Enhanced Features

This suite provides comprehensive hardware detection and optimization for Intel Meteor Lake and newer platforms with specific enhancements for:

### Hardware Detection
- **NPU/VPU**: Intel Neural Processing Unit (3720 for Meteor Lake, 4000 for Lunar Lake)
- **GNA**: Gaussian Neural Accelerator for low-power inference
- **Intel Graphics**: Arc/Xe/Xe2 GPU architectures
- **AMX**: Advanced Matrix Extensions (Tile, INT8, BF16, FP16)
- **AVX-VNNI**: Including INT8/INT16 extensions
- **SGX, QAT, DSA, IAA**: Security and acceleration features

### Files Included

1. **install_intel_suite.sh** - Master installer that sets up everything
2. **intel_meteor_lake_deploy.sh** - Deployment script with hardware detection
3. **intel_system_analyzer.py** - Python-based comprehensive system analyzer
4. **Makefile.meteor_lake** - Example Makefile with optimization profiles
5. **METEOR_LAKE_README.md** - Complete documentation

## 📋 Quick Start Guide

### One-Command Installation
```bash
chmod +x install_intel_suite.sh
./install_intel_suite.sh ~/intel_opt_suite
source ~/intel_opt_suite/activate.sh
```

### System Analysis
```bash
# Run comprehensive analysis
intel_analyze.py

# Or use the Python analyzer directly
python3 intel_system_analyzer.py
```

### Using Optimal Flags
```bash
# After activation, use the environment variables:
gcc $CFLAGS_OPTIMAL -o myapp myapp.c $LDFLAGS_OPTIMAL

# For AI workloads with NPU:
gcc $CFLAGS_OPENVINO -o ai_app ai_app.c -lopenvino

# For P-core only (AVX-512):
taskset -c 0-7 gcc $CFLAGS_PCORE -o compute compute.c
```

## 🔧 Detected Optimizations

### For Your Meteor Lake System

Based on your chat history mentioning NPU/GNA capabilities:

#### Confirmed Features:
- **CPU**: Intel Meteor Lake (Core Ultra 1st Gen)
- **NPU**: VPU 3720 present
- **GNA**: Available for low-power inference
- **GPU**: Intel Arc Graphics (Xe-LPG architecture)
- **Hybrid**: P-cores + E-cores configuration

#### Optimal Flags Generated:
```bash
# Base architecture
-march=meteorlake -mtune=meteorlake

# AI acceleration (critical for your workloads)
-mavxvnni -mavxvnniint8 -mavxvnniint16
-mavxifma -mavxneconvert

# AMX support (if enabled in BIOS)
-mamx-tile -mamx-int8 -mamx-bf16

# Crypto acceleration
-maes -mvaes -mpclmul -mvpclmulqdq -mgfni -msha

# Advanced features
-mserialize -mtsxldtrk -muintr -mwaitpkg
-mcldemote -mmovdiri -mmovdir64b
```

## 🎯 NPU/OpenVINO Configuration

### NPU Activation
```bash
# Environment setup (automatic after installation)
export OPENVINO_DEVICE_PRIORITY="NPU,GPU,CPU"
export OV_NPU_COMPILER_TYPE=DRIVER
export OV_NPU_PLATFORM=3720
export OV_NPU_ENABLE_ELTWISE_UNROLL=YES
export OV_NPU_ENABLE_CONCAT_OPTIMIZATION=YES
```

### OpenVINO Build Flags
```bash
-DENABLE_INTEL_CPU=ON
-DENABLE_INTEL_NPU=ON
-DNPU_DEVICE_NAME=NPU.3720
-DENABLE_INTEL_GPU=ON
-DINTEL_GPU_ARCH=xe-lpg
-DENABLE_INTEL_GNA=ON
-DENABLE_HETERO=ON
-DENABLE_MULTI=ON
-DENABLE_AUTO=ON
```

## 🔍 Troubleshooting

### NPU Not Detected
```bash
# Check kernel module
lsmod | grep -E "intel_vpu|ivpu"

# Load module
sudo modprobe intel_vpu_accel

# Check permissions
ls -la /dev/accel/
sudo usermod -aG render $USER
```

### OpenVINO Not Working
```bash
# Install OpenVINO 2024.0
wget https://storage.openvinotoolkit.org/repositories/openvino/packages/2024.0/linux/l_openvino_toolkit_ubuntu22_2024.0.0.14509.34caeefd078_x86_64.tgz
tar -xzf l_openvino_toolkit_*.tgz
cd l_openvino_toolkit_*/
sudo ./install_dependencies/install_openvino_dependencies.sh
source /opt/intel/openvino_2024/setupvars.sh
```

### Testing NPU
```python
import openvino as ov
core = ov.Core()
devices = core.available_devices
print("Available devices:", devices)  # Should show ['NPU', 'GPU', 'CPU']
```

## 📊 Benchmark Example

```c
// vnni_npu_bench.c
#include <immintrin.h>
#include <stdio.h>
#include <time.h>

int main() {
    // VNNI operations (runs on CPU, accelerated)
    __m256i a = _mm256_set1_epi8(1);
    __m256i b = _mm256_set1_epi8(2);
    __m256i c = _mm256_setzero_si256();
    
    clock_t start = clock();
    for(long i = 0; i < 1000000000L; i++) {
        c = _mm256_dpbusd_epi32(c, a, b);
    }
    clock_t end = clock();
    
    printf("VNNI INT8 ops/sec: %.2fG\n", 
           1.0 / ((double)(end - start) / CLOCKS_PER_SEC));
    return 0;
}

// Compile with:
// gcc $CFLAGS_OPTIMAL vnni_npu_bench.c -o vnni_bench
// ./vnni_bench
```

## 🛠️ Advanced Usage

### P-Core Only Mode (AVX-512)
```bash
# Disable E-cores temporarily
for cpu in {8..19}; do
    echo 0 | sudo tee /sys/devices/system/cpu/cpu$cpu/online
done

# Run on P-cores only
taskset -c 0-7 ./avx512_app

# Re-enable E-cores
for cpu in {8..19}; do
    echo 1 | sudo tee /sys/devices/system/cpu/cpu$cpu/online
done
```

### Profile-Guided Optimization
```bash
# Step 1: Build with profiling
gcc $CFLAGS_OPTIMAL -fprofile-generate -o app app.c

# Step 2: Run with representative workload
./app < workload.txt

# Step 3: Build with profile data
gcc $CFLAGS_OPTIMAL -fprofile-use -o app app.c
```

## 📚 Key Environment Variables

After activation, these are available:
- `$CFLAGS_OPTIMAL` - Best general optimization
- `$CFLAGS_PCORE` - P-core only with AVX-512
- `$CFLAGS_SECURE` - Security hardened
- `$CFLAGS_OPENVINO` - OpenVINO builds
- `$OPENVINO_DEVICE_PRIORITY` - Device execution order

## 🔒 Security Considerations

For KYBERLOCK and sensitive workloads:
```bash
# Use secure flags
export CFLAGS="$CFLAGS_SECURE"
export LDFLAGS="$LDFLAGS_SECURE"

# Additional hardening
-D_FORTIFY_SOURCE=3
-fstack-protector-strong
-fcf-protection=full
-Wl,-z,relro -Wl,-z,now
```

## ✨ What's New in v7.0

- **Complete NPU/VPU detection** for Meteor Lake (3720) and Lunar Lake (4000)
- **GNA support** for low-power Gaussian inference
- **Intel Arc GPU detection** with Xe-LPG/Xe2-LPG architecture identification
- **AMX detection** including INT8/BF16/FP16 variants
- **AVX-VNNI INT8/INT16** for enhanced AI workloads
- **Automatic OpenVINO configuration** based on detected hardware
- **Python system analyzer** with JSON output
- **Comprehensive Makefile** with workload profiles
- **Master installer** with environment activation

## 🚦 Known Limitations

1. **NPU**: Models >100MB may require CPU/GPU fallback
2. **AVX-512**: Disabled when E-cores active (frequency impact)
3. **AMX**: Requires kernel 5.18+ and XSAVE support
4. **GNA**: Limited to FC/CNN/RNN layers
5. **OpenVINO**: Some models need FP32 fallback on NPU

## 📧 Support

For issues specific to your Meteor Lake system:
1. Run `intel_analyze.py` and save output
2. Check `dmesg | grep -E "vpu|npu|gna"` for driver issues
3. Verify with `ls -la /dev/accel/ /dev/gna*`

---

**KYBERLOCK Research Division**
*Tactical Computing - Hardware Acceleration Unit*
*Version 7.0 - November 2024*
