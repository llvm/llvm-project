# Intel Meteor Lake Optimization Suite v7.0
## Enhanced NPU/GNA/GPU Detection & Optimization

### Overview
This enhanced suite provides comprehensive hardware detection and optimization for Intel Meteor Lake and newer platforms, with specific support for:
- **NPU (Neural Processing Unit)** - VPU 3720 (Meteor Lake) / NPU 4000 (Lunar Lake)
- **GNA (Gaussian Neural Accelerator)** - Low-power inference
- **Intel Arc Graphics** - Xe-LPG/Xe2-LPG architectures
- **AMX (Advanced Matrix Extensions)** - Tile/INT8/BF16/FP16 operations
- **AVX-VNNI** - Including INT8/INT16 extensions for AI workloads
- **OpenVINO Integration** - Automatic configuration for AI acceleration

### Hardware Support

#### CPU Architectures
- **Meteor Lake** (Core Ultra 1xx): Full NPU/GPU/AMX support
- **Lunar Lake** (Core Ultra 2xx): Enhanced NPU Gen4, Xe2 graphics
- **Arrow Lake**: Desktop variant with enhanced P-cores
- **Raptor Lake**: Fallback support without NPU
- **Alder Lake**: Baseline hybrid architecture

#### Accelerator Detection
The suite automatically detects:
1. **NPU/VPU** via `/dev/accel/accel*` or `/dev/vpu*`
2. **GNA** via `/dev/gna0`
3. **Intel Graphics** via DRM subsystem
4. **SGX** secure enclaves
5. **QAT** crypto acceleration
6. **DSA/IAA** data streaming accelerators

### Installation & Usage

```bash
# 1. Deploy the suite
chmod +x intel_meteor_lake_deploy.sh
sudo ./intel_meteor_lake_deploy.sh

# 2. Source the generated flags
source optimal_flags.sh

# 3. Use in compilation
gcc $CFLAGS_OPTIMAL -o myapp myapp.c
g++ $CXXFLAGS_OPTIMAL -o myapp myapp.cpp

# For AI/ML workloads with OpenVINO
gcc $CFLAGS_OPENVINO -o ai_app ai_app.c -lopenvino

# For P-core only workloads (AVX-512)
taskset -c 0-7 gcc $CFLAGS_PCORE -o compute compute.c
```

### Generated Compiler Flags

#### Base Flags
```bash
CFLAGS_BASE="-O3 -pipe -fomit-frame-pointer -funroll-loops 
             -fstrict-aliasing -fno-plt -fdata-sections 
             -ffunction-sections -flto=auto"
```

#### Meteor Lake Specific
```bash
# Architecture tuning
-march=meteorlake -mtune=meteorlake

# AI/ML acceleration (detected at runtime)
-mavxvnni           # AVX-VNNI base
-mavxvnniint8       # INT8 dot products
-mavxvnniint16      # INT16 operations
-mavxifma           # Integer FMA
-mavxneconvert      # BF16/FP16 conversions

# AMX (if available on your SKU)
-mamx-tile          # Tile operations
-mamx-int8          # INT8 matrix multiply
-mamx-bf16          # BF16 matrix multiply
-mamx-fp16          # FP16 matrix multiply

# Advanced features
-mserialize         # Serializing instructions
-mtsxldtrk          # TSX suspend/resume
-muintr             # User interrupts
-mwaitpkg           # UMONITOR/UMWAIT
-mcldemote          # Cache line demote
-mmovdiri           # Direct stores
-mmovdir64b         # 64-byte direct stores
```

#### OpenVINO Configuration
When NPU/GPU is detected:
```bash
# Build flags
CFLAGS_OPENVINO includes:
-DENABLE_INTEL_CPU=ON
-DENABLE_INTEL_NPU=ON       # If NPU present
-DENABLE_INTEL_GPU=ON       # If GPU present
-DINTEL_GPU_ARCH=xe-lpg     # Meteor Lake GPU
-DNPU_DEVICE_NAME=NPU.3720  # Meteor Lake NPU

# Runtime environment
OPENVINO_DEVICE_PRIORITY="NPU,GPU,CPU"
OV_NPU_COMPILER_TYPE=DRIVER
OV_NPU_PLATFORM=3720
OV_GPU_ENABLE_SDPA_OPTIMIZATION=YES
```

### NPU/VPU Specifics

#### Meteor Lake (VPU 3720)
- 2x Neural Compute Engines
- INT8/FP16 inference
- Power efficiency: 1-2W typical
- OpenVINO device name: `NPU.3720`
- Driver: Intel Level Zero

#### Lunar Lake (NPU 4000)
- 4x Neural Compute Engines
- Enhanced INT8/INT4 support
- Power efficiency: <1W typical
- OpenVINO device name: `NPU.4000`

#### Optimal NPU Usage
```bash
# Set NPU as primary device
export OPENVINO_DEVICE_PRIORITY="NPU,CPU"

# Enable NPU optimizations
export OV_NPU_ENABLE_ELTWISE_UNROLL=YES
export OV_NPU_ENABLE_CONCAT_OPTIMIZATION=YES
export OV_NPU_ENABLE_WEIGHTS_ANALYSIS=YES
export OV_NPU_DPU_GROUPS=2
export OV_NPU_DMA_ENGINES=2

# For models >100MB, use CPU fallback
export OPENVINO_DEVICE_PRIORITY="AUTO"
```

### Intel Graphics (Xe-LPG)

#### Meteor Lake Graphics
- Architecture: Xe-LPG (128 EUs max)
- DirectX 12.1, Vulkan 1.3
- AV1 decode, HEVC encode/decode
- Ray tracing support (Tier 1)

#### Optimization Flags
```bash
# For compute shaders
export CFLAGS_GPU_COMPUTE="$CFLAGS_OPTIMAL -fopenmp -fopenmp-targets=spir64"

# For Intel GPU via OpenCL
export INTEL_GPU_OPENCL_FLAGS="-cl-fast-relaxed-math -cl-mad-enable"

# For Level Zero
export ZE_FLAT_DEVICE_HIERARCHY=COMPOSITE
export ZE_AFFINITY_MASK=0
```

### Performance Tuning

#### CPU Affinity for Hybrid Architectures
```bash
# P-cores only (best single-thread)
taskset -c 0-7 ./app

# E-cores only (best efficiency)
taskset -c 8-19 ./app

# Disable E-cores for AVX-512
echo 0 | sudo tee /sys/devices/system/cpu/cpu{8..19}/online
```

#### Memory & Cache Optimization
```bash
# Huge pages for large workloads
echo 1024 | sudo tee /proc/sys/vm/nr_hugepages
export MALLOC_MMAP_THRESHOLD_=2097152
export MALLOC_MMAP_MAX_=65536

# Prefetching control
export CFLAGS_PREFETCH="-fprefetch-loop-arrays -mprefetchw"
```

### Troubleshooting

#### NPU Not Detected
```bash
# Check kernel modules
lsmod | grep -E "intel_vpu|ivpu"

# Load module manually
sudo modprobe intel_vpu_accel

# Check permissions
ls -la /dev/accel/
# Add user to render group
sudo usermod -aG render $USER
```

#### OpenVINO Not Working
```bash
# Install OpenVINO runtime
wget https://storage.openvinotoolkit.org/repositories/openvino/packages/2024.0/linux/l_openvino_toolkit_ubuntu22_2024.0.0.14509.34caeefd078_x86_64.tgz
tar -xzf l_openvino_toolkit_*.tgz
cd l_openvino_toolkit_*/
sudo ./install_dependencies/install_openvino_dependencies.sh
source /opt/intel/openvino_2024/setupvars.sh
```

#### GNA Issues
```bash
# Check GNA driver
dmesg | grep -i gna

# Load GNA module
sudo modprobe intel_gna

# Set GNA mode
echo "hw" | sudo tee /sys/class/gna/gna0/recovery_timeout
```

### Benchmark Examples

#### Test VNNI Performance
```c
// vnni_bench.c
#include <immintrin.h>
#include <stdio.h>
#include <time.h>

int main() {
    __m256i a = _mm256_set1_epi8(1);
    __m256i b = _mm256_set1_epi8(2);
    __m256i c = _mm256_setzero_si256();
    
    clock_t start = clock();
    for(long i = 0; i < 1000000000L; i++) {
        c = _mm256_dpbusd_epi32(c, a, b);
    }
    clock_t end = clock();
    
    printf("VNNI ops/sec: %.2fG\n", 
           1.0 / ((double)(end - start) / CLOCKS_PER_SEC));
    return 0;
}

// Compile: gcc $CFLAGS_OPTIMAL vnni_bench.c -o vnni_bench
```

#### Test NPU Inference
```python
# npu_test.py
import openvino as ov

core = ov.Core()
model = core.read_model("model.xml")
compiled = core.compile_model(model, "NPU")
infer_req = compiled.create_infer_request()
result = infer_req.infer({"input": data})
print(f"NPU inference time: {infer_req.latency}ms")
```

### Security Considerations

#### When Using Secure Flags
```bash
# For production/sensitive workloads
export CFLAGS="$CFLAGS_SECURE"
export LDFLAGS="$LDFLAGS_SECURE"

# Additional hardening
-D_FORTIFY_SOURCE=3         # Runtime buffer checks
-fstack-protector-strong    # Stack canaries
-fcf-protection=full        # Control-flow protection
-fpie -pie                  # Position independent
-Wl,-z,relro -Wl,-z,now    # Full RELRO
```

### Known Limitations

1. **NPU**: Models >100MB may fail, use CPU/GPU fallback
2. **GNA**: Limited to specific layer types (FC, CNN, RNN)
3. **AVX-512**: Disabled when E-cores active (frequency throttling)
4. **AMX**: Requires kernel 5.18+ and explicit XSAVE support
5. **OpenVINO**: Some models require FP32 fallback on NPU

### Environment Variables Summary

```bash
# Essential for Meteor Lake
export INTEL_NPU_PRESENT=1
export INTEL_NPU_GEN=3720
export INTEL_GPU_PRESENT=1
export INTEL_GPU_GEN=xe-lpg
export OPENVINO_DEVICE_PRIORITY="NPU,GPU,CPU"

# Performance tuning
export OMP_NUM_THREADS=8        # P-cores only
export MKL_NUM_THREADS=8
export OV_CPU_DENORMALS_OPTIMIZATION=YES
export OV_CPU_SPARSE_WEIGHTS_DECOMPRESSION_RATE=0.8

# Debug/profiling
export OV_NPU_PROFILING=ON      # Enable NPU profiling
export OV_GPU_VERBOSE=1          # GPU debug output
export SYCL_PI_TRACE=1           # SYCL tracing
```

### Further Resources

- [Intel OpenVINO Documentation](https://docs.openvino.ai/)
- [Intel NPU Driver](https://github.com/intel/linux-npu-driver)
- [Level Zero Specification](https://spec.oneapi.io/level-zero/)
- [Intel Graphics Compiler](https://github.com/intel/intel-graphics-compiler)

### Version History

- **v7.0**: Added comprehensive NPU/GNA/GPU detection for Meteor Lake
- **v6.0**: Base AVX-512 and hybrid architecture support
- **v5.0**: Initial Alder Lake optimization

### License
KYBERLOCK Research - Tactical Computing Division
